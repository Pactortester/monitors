from monitors.version import __version__
